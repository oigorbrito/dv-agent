UNITS = {"d": 86400, "h": 3600, "m": 60, "s": 1}


def parse_duration(text):
    """Parse a duration into seconds (see the task prompt)."""
    total = 0
    number = ""
    for ch in text:
        if ch.isdigit():
            number += ch
        elif ch in UNITS:
            total += int(number) * UNITS[ch]
            number = ""
    return total
