def slugify(text, max_len=50):
    """Return a lowercase ASCII slug (see the task prompt)."""
    s = text.lower().strip().replace(" ", "-")
    return s[:max_len]
